#include <cstdint>
#include <iostream>
#include <string> 
#include <sstream>
#include <cstring>
#include "cachesim.h"
#include <cmath>
#include <map>

// what all i need to do for this is that  2)need to make a report 3) check logic is fine or not 4)change variable names 
bool isPowerofTwo(int num) {
  
    return (num & (num-1)) == 0;
}
bool validByte(char *byte) { 
    int bytes;
    bytes = std::stoi(byte);

    if (bytes < 4 || !isPowerofTwo(bytes)) {
        return false;
    } else {
        return true;
    }
    return false;
}
bool validSetvalidBlock(char* set, char* block) {
    try {
        int blocksize = std::stoi(block);
        int setsize = std::stoi(set);
        if (setsize <= 0 || blocksize <= 0) {
            return false;
        }
        return (isPowerofTwo(setsize) && isPowerofTwo(blocksize));
    }   
    catch (std::invalid_argument& e) {
        return false;
    }
}
bool validOption(char* input, char* option1, char* option2) {
    int validOption2 = strcmp(input, option2);
    int validOption1 = strcmp(input, option1);    
    if (validOption1 == 0 || validOption2 == 0) {
        return true;
    }
    return false;
}

bool validParameters(int argc, char** argv) {
    if (argc != 7 ||
        !validSetvalidBlock(argv[1], argv[2]) ||
        !validByte(argv[3]) ||
        !validOption(argv[4], (char*)"write-allocate", (char*)"no-write-allocate") ||
        !validOption(argv[5], (char*)"write-through", (char*)"write-back") ||
        !validOption(argv[6], (char*)"lru", (char*)"fifo") ||
        (strcmp(argv[4], "no-write-allocate") == 0 && strcmp(argv[5], "write-back") == 0)) {
        
        std::cerr << "Invalid Parameters" << std::endl;
        return false;
    }
    return true;
}
uint32_t getTag(int bytes, uint32_t address, int sets) {   
    int offsetbits = log2(bytes);
    int indexbits = log2(sets);   
    uint32_t tag = 0 ; 
    if (sets == 1) {
        uint32_t tag = address >> (offsetbits);
        return tag;
        
    }else{
        uint32_t tag = address >> (offsetbits + indexbits);
        return tag;
    }  
    return tag;
}

uint32_t getIndex(int bytes, uint32_t address, int sets) {
    int offsetbits = log2(bytes);
    int indexbits = log2(sets);
    if (sets == 1) {
        return 0;
    }
    uint32_t indexMask = ((1 << indexbits) - 1) << offsetbits;
    uint32_t index = (address & indexMask) >> offsetbits;
    return index;    
}

Cache initializeCache(int numOfSets, int numOfSlotsPerSet) {
    Cache cache;    
    cache.sets.resize(numOfSets);    
    for (int i = 0; i < numOfSets; ++i) {
        Set set;       
        set.slots.resize(numOfSlotsPerSet);          
        for (int j = 0; j < numOfSlotsPerSet; ++j) {
            Slot slot;           
            slot.dirty = false;   
            slot.valid = false;
            slot.access_ts = 0;        
            slot.load_ts = 0;
                      
            set.slots[j] = slot; 
        }        
        cache.sets[i] = set;
    }
    
    cache.counter = 0;
    return cache;
}

int cacheLoad(Cache& cache, uint32_t index, uint32_t tag, int data_size, bool write_through, bool lru) {
    Set& cacheSet = cache.sets[index];    
    if (cacheSet.tagMap.find(tag) != cacheSet.tagMap.end()) {
        Slot& slot = *cacheSet.tagMap.at(tag);        
        if (slot.valid && slot.tag == tag) {
            cache.counter++;
            slot.access_ts = cache.counter;
            return 1; 
        }
    }   
    int cycles = 0, slotToUpdate = 0;
    slotToUpdate = findAvailableSlotIndex(cacheSet);    
    if (slotToUpdate == -1) {
        slotToUpdate = findReplacementIndex(cacheSet, lru);       
        cacheSet.tagMap.erase(cacheSet.slots[slotToUpdate].tag);
    }   
    Slot& updatedSlot = cacheSet.slots[slotToUpdate];    
    if (updatedSlot.dirty && !write_through) {
        cycles += 100*(data_size/4);
    }   
    updateSlotParameters(cache, cacheSet, updatedSlot, tag, write_through, true);    
    cycles += 100*(data_size/4);
    return cycles;
}
int cacheStore(Cache& cache, uint32_t index, uint32_t tag, int data_size, bool write_allocate, bool write_through, bool lru, bool* hit) {
    Set& cacheSet = cache.sets[index];
    int cycles = 0;
    if (cacheSet.tagMap.find(tag) != cacheSet.tagMap.end()) {
        Slot& slot = *cacheSet.tagMap.at(tag);
        *hit = true;
        cache.counter++;
        slot.access_ts = cache.counter;
        if (write_through) {
            cycles = 100;
        } else {
            slot.dirty = true;
            cycles = 1;
        }
    } else {
        cycles = handleStoreMiss(cache, cacheSet, tag, data_size, write_allocate, write_through, lru);
    }
    return cycles;
}
int handleStoreMiss(Cache& cache, Set& cacheSet, uint32_t tag, int data_size, bool write_allocate, bool write_through, bool lru) {
    if (!write_allocate) {        
        return 100;
    }
    int cycles = 0, slotToUpdate = 0;   
    slotToUpdate = findAvailableSlotIndex(cacheSet);   
    if (slotToUpdate == -1) {
        slotToUpdate = findReplacementIndex(cacheSet, lru);   
        cacheSet.tagMap.erase(cacheSet.slots[slotToUpdate].tag);
    }   
    Slot& updateSlot = cacheSet.slots[slotToUpdate];
       if (write_through) {
        cycles = 100+(100*(data_size/4)); 
    }
    else {        
        if (updateSlot.dirty) {
            cycles = 2*(100*(data_size/4));
        }
        else {
            cycles = 100*(data_size/4);
        }
    }
   
    updateSlotParameters(cache, cacheSet, updateSlot, tag, write_through, false);
    return cycles;
}
int findAvailableSlotIndex(Set& cacheSet) {
    
    for (int i = 0; i < (int) cacheSet.slots.size(); i++) {
        if (cacheSet.slots[i].valid == false) {
            return i;
        }
    }

    return -1;
}
int findReplacementIndex(Set& cacheSet, bool lru) {
    int index = 0;
    if (lru) {
        uint32_t leastUsed = cacheSet.slots[0].access_ts;
       
        for (int i = 1; i < (int) cacheSet.slots.size(); ++i) {
            if (cacheSet.slots[i].access_ts < leastUsed) {
                leastUsed = cacheSet.slots[i].access_ts;
                index = i;
            }
        }
    }
    else {
        uint32_t oldest = cacheSet.slots[0].load_ts;
           
        for (int i = 1; i < (int) cacheSet.slots.size(); ++i) {
            if (cacheSet.slots[i].load_ts < oldest) {
                oldest = cacheSet.slots[i].load_ts;
                index = i;
            }
        }
    }
    return index;
}
void updateSlotParameters(Cache& cache, Set& cacheSet, Slot& updateSlot, uint32_t tag, bool write_through, bool load) {
    updateSlot.tag = tag;
    updateSlot.valid = true;
    cache.counter++;
    updateSlot.access_ts = cache.counter;
    updateSlot.load_ts = cache.counter;
   
    if (load) {
        updateSlot.dirty = false;
    }
    
    else {
        if (write_through) {
            updateSlot.dirty = false;
        }
        else {
            updateSlot.dirty = true;
        }
    }
    cacheSet.tagMap[tag] = &updateSlot;
}
