Command to Run:

make

./cacheSim 256 8 256 write-allocate write-back fifo < some_trace_file

Cache Load Operation:
- If the requested data is found in the cache (cache hit), no additional cycles are added apart from the basic access time. So, it adds 100 cycles per data transfer (assuming each data size is 4 bytes).
- If the data is not found in the cache (cache miss), additional cycles are added:
  - Finding an available slot: No additional cycles.
  - Finding a replacement slot: Dependent on the cache replacement policy (LRU or FIFO).
  - Updating slot parameters: No additional cycles apart from the basic access time.

Cache Store Operation:
- If the data to be stored is found in the cache (cache hit), the number of additional cycles depends on the write policy:
  - If it's a write-through policy, 100 cycles are added (assuming each data size is 4 bytes).
  - If it's a write-back policy, 1 cycle is added for updating the access timestamp, and the dirty bit is set.
- If the data is not found in the cache (cache miss), additional cycles are added:
  - Finding an available slot: No additional cycles.
  - Finding a replacement slot: Dependent on the cache replacement policy (LRU or FIFO).
  - Updating slot parameters: Dependent on the write policy and whether write-allocate is enabled.

Handling Store Miss:
- If write-allocate is disabled, 100 cycles are added for handling the miss.
- If write-allocate is enabled, additional cycles are added based on the write policy:
  - For write-through policy: 100 cycles + data transfer cycles.
  - For write-back policy: 2 * data transfer cycles if the slot being replaced is dirty, otherwise data transfer cycles.

Miscellaneous:
- Finding an available slot index: No additional cycles.
- Finding a replacement index: Depends on the cache replacement policy and the method used (LRU or FIFO).


