// Do NOT add any other includes
#include "dict.h"

Dict::Dict(){
    // Implement your function here    
}

Dict::~Dict(){
    // Implement your function here    
}

void Dict::insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence){
    // Implement your function here  
    return;
}

int Dict::get_word_count(string word){
    // Implement your function here  
    return -1;
}

void Dict::dump_dictionary(string filename){
    // Implement your function here  
    return;
}