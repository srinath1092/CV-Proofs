Compilation
To compile the code, use the following command:

g++ tester.cpp dict.cpp search.cpp qna_tool.cpp -o test

This will create an executable file named test.

Execution
To run the program, use the following command:

./test

Output
Upon  execution, you will see the output as the five paragraphs we have returned and the chat GPT’s reply.

Please note that the actual output may vary based on the input data and parameters used.