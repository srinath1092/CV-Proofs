open Sig

let load_database filename =
  let file = open_in filename in
  let lexbuf = Lexing.from_channel file in
  let rec collect acc =
    match Parser.line Lexer.token lexbuf with
    | Node(("_end", 0), []), [] -> acc
    | x -> collect (x :: acc)
  in
  List.rev (collect [])

let database = prepend_vars_ (load_database Sys.argv.(1))

let _ = print_endline "\nQueries:\n"

let _ =
  let lexbuf = Lexing.from_channel stdin in
  while true do
    print_string "?- "; flush stdout;
    let goal = Parser1.line Lexer1.token lexbuf in
    match goal with
    | [Node(("exit", 0), [])] -> print_endline "Exit\n"; exit 0
    | y -> solve_goal_multiple y database
  done
