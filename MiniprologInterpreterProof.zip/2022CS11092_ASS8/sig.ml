
open List
open Avltree

(*#use "avltree.ml";;
*)
exception Not_found
exception NOT_UNIFIABLE
exception Impossible

type variable = string;; (*name*)
type symbol = string * int;; (*name, arity*) (*TODO: check if this is okay*)
type term = V of variable | Node of symbol * (term list);;
type substitution = (variable * term) tree;;
type clause = term * (term list);;

let global_state = ref 0;;


(*-----------------sorted list functions--------------------*)

let rec list_differnce l1 l2 comp =
    let rec loop acc l1 l2 =
      match (l1, l2) with
      | (_, []) -> List.rev_append acc l1
      | ([], _) -> acc
      | (x :: xs, y :: ys) ->
          let res = comp x y in
          if res = 0 then loop acc xs ys
          else if res < 0 then loop (x :: acc) xs l2
          else loop acc l1 ys
    in
    loop [] l1 l2
  

let rec union_of_list l1 l2 comp =
    let rec loop acc l1 l2 =
        match (l1, l2) with
        | ([], _) -> List.rev_append acc l2
        | (_, []) -> List.rev_append acc l1
        | (x :: xs, y :: ys) ->
            let res = comp x y in
            if res = 0 then loop (x :: acc) xs ys
            else if res < 0 then loop (x :: acc) xs l2
            else loop (y :: acc) l1 ys
    in
    loop [] l1 l2
      


(*-----------comparator functions for symbols (weak and strong)------------*)

let string_comparison x y = if x > y then 1 else if x < y then -1 else 0;;

let weak_symbol_comparison x y =
    let compare_first_element (s1, _) (s2, _) = string_comparison s1 s2 in
    compare_first_element x y
  
(*Note that this function checks only for duplicate names*)

let symbol_comp x y = 
    match (x, y) with 
    | ((s, a), (t, b)) -> 
            let w = string_comparison s t in 
                if w = 0 then if a > b then 1 else if a < b then -1 else 0
                else w;;
(*this strictly checks for equality*)



(*--------------------------signatures and terms--------------------------*)

(*To check if a signature is valid - this function checks if duplicate symbol names exist, and arities are non-negative (also assumes that the same symbol with the same arity can't come twice)*)
    let check_sig (signature : symbol list) : bool =
        let insert_unique_symbol found (sym, ari) =
          if ari >= 0 && not (find_bool found (sym, ari) weak_symbol_comparison) then
            insert found (sym, ari) weak_symbol_comparison
          else
            raise Impossible
        in
        try
          let _ = List.fold_left insert_unique_symbol Leaf signature in
          true
        with
        | Impossible -> false
      

(*In the case that it is a variable, we need to check if its name clashes with a symbol name, else if it is a symbol, we check if the symbol is there in the signature or not, and the arity matches the number of terms in the corresponding list of the node, and each of the terms in the list must be well-formed*)
let rec wfterm (preterm : term) (signature : symbol list) =
    let sig_tree = list_to_tree signature weak_symbol_comparison in
    let rec wfterm_ pre_ =
        match pre_ with
        | V v -> not (find_bool sig_tree (v, 0) weak_symbol_comparison)
        | Node ((symname, symarity), l) ->
            let check_subterms = List.map wfterm_ l in
            let arity_match = List.length l = symarity in
            let symbol_match = find_bool sig_tree (symname, symarity) symbol_comp in
            List.fold_left (&&) (arity_match && symbol_match) check_subterms
    in
    wfterm_ preterm
      

(*To find the height of the preterm*)
let rec ht (preterm : term) = 
    match preterm with
    | V (v) -> 0
    | Node ((sym, ari), l) -> 1 + List.fold_left max 0 (List.rev_map ht l);;

(*To find the size of the preterm*)
let rec size (preterm : term) =
    match preterm with 
    | V (v) -> 1
    | Node ((sym, ari), l) -> 1 + List.fold_left (fun x y -> x + y) 0 (List.rev_map size l);;

(*To find the set of variables in a preterm in sorted order - we can inductively show that the order is sorted*)
let rec vars (preterm : term) =
    let rec vars_helper preterm acc =
      match preterm with
      | V v -> v :: acc
      | Node (_, l) -> List.fold_right vars_helper l acc
    in
    vars_helper preterm []
  



(*-----------------------substitution helper functions--------------------------*)

let substitution_comparison ((v1, t1) : (variable * term)) ((v2, t2) : (variable * term)) = 
    string_comparison v1 v2;; (*Compares only names*)

(*applies the substitution s1 to term t*)
let rec apply_substitution (s1 : substitution) (t : term) =
    let apply_single_subst (v, term) =
      if find_bool s1 (v, V v) substitution_comparison then
        match find_element s1 (v, V v) substitution_comparison with
        | (_, ret) -> ret
      else
        V v
    in
    match t with
    | V v -> apply_single_subst (v, V v)
    | Node ((sym, ari), l) ->
        let mapped_subst = List.map (apply_substitution s1) l in
        Node ((sym, ari), mapped_subst)
  

(*removes redundancies in a list of variable to term mappings by removing those elements which are of the form (v, V v)*)
let remove_redundancies (l : (variable * term) list) : (variable * term) list = 
    let rec help s acc = 
        match s with
        | [] -> acc
        | (v, V w) :: xs -> if v = w then help xs acc else help xs ((List.hd s) :: acc)
        | (v, _) :: xs -> help xs ((List.hd s) :: acc)
    in List.rev (help l []);;

(*finds a composition of the two substitutions s1 and s2*)
let subst_composition (s1 : substitution) (s2 : substitution) : substitution = (*s1 applied, then s2 applied - this is equivalent to 'sprouting' of those variables which are in s1 and union with the elements which are in s2 but not in s1. We assume that both s1 and s2 are valid, and there is no variable whose substitutions have been defined more than once *)
    let (sl1, sl2) = ((tree_to_list s1), (tree_to_list s2))
    in
    list_to_tree (remove_redundancies (union_of_list (List.rev (List.rev_map (fun (x, t) -> (x, (apply_substitution s2 t))) sl1)) (list_differnce sl2 sl1 substitution_comparison) substitution_comparison)) substitution_comparison;;

let occurs (v : variable) (t : term) = List.fold_left (fun x y -> x || (y = v)) false (vars t);;

let rec mgu (t1 : term) (t2 : term) : substitution =
    let rec mgu_helper t1 t2 =
      match (t1, t2) with
      | V v1, V v2 -> if v1 = v2 then Leaf else insert Leaf (v1, V v2) substitution_comparison
      | V v, Node (sym, l) | Node (sym, l), V v ->
          if not (List.exists (occurs v) l) then insert Leaf (v, Node (sym, l)) substitution_comparison
          else raise NOT_UNIFIABLE
      | Node (sym1, l1), Node (sym2, l2) ->
          if sym1 <> sym2 then raise NOT_UNIFIABLE
          else List.fold_left2 (fun s t1 t2 -> subst_composition s (mgu_helper (apply_substitution s t1) (apply_substitution s t2))) Leaf l1 l2
    in
    mgu_helper t1 t2

(*printing functions*)

let print_var v = Printf.printf "%s" v;;

let rec print_term_ t = 
    match t with
    | V v -> print_var v
    | Node ((sname, arity), l) ->
            if(arity = 0) then Printf.printf "%s" sname
            else
                (
                Printf.printf "%s(" sname;
                let rec print_term_list l = 
                    match l with
                    | [] -> Printf.printf ""
                    | [x] -> print_term_ x
                    | x :: xs -> print_term_ x; Printf.printf ", "; print_term_list xs
                in
                print_term_list l;
                Printf.printf ")"
                )
;;

let print_term t = print_term_ t; Printf.printf "\n";;

let rec print_term_list tl = 
    match tl with
    | [] -> Printf.printf ".\n"
    | [x] -> print_term_ x; Printf.printf ".\n"
    | x :: xs -> print_term_ x; Printf.printf ", "; print_term_list xs
;;

let print_clause (c, cl) = 
    if(List.length cl = 0) then (print_term_ c; Printf.printf ".\n") else (print_term_ c; Printf.printf " :- "; print_term_list cl)
;;

let print_one_var_subs (v, t) = 
    print_var v; Printf.printf " -> "; print_term t
;;

let rec print_substitution s = 
    match s with
    | Leaf -> ()
    | Node (left, data, right, _) -> print_substitution left; print_one_var_subs data; print_substitution right
;;  

let check_cap_alpha c =
    match c with
    | 'A' .. 'Z' -> true
    | _ -> false

let get_rev_prefix s = (*gives prefix and the varname of s*)
    let len = String.length s
    in
    let rec help i acc = 
        if i >= len || (check_cap_alpha s.[i]) then (acc, String.sub s i (len - i))
        else help (i+1) (s.[i] :: acc)
    in
    let rec list_to_string l = 
        match l with (x, str) -> (String.concat "" ((List.rev_map (String.make 1) x)), str)
    in
    list_to_string (help 0 [])
;;

let rec prefixes_of_string_list l = 
    tree_to_list (List.fold_left (fun y x -> match (get_rev_prefix x) with (pre, varname) -> if find_bool y pre default_comp then y else insert y pre default_comp) Leaf l)
;;

let index_in_list a b = 
    let rec help i l =
        match l with 
        | [] -> i
        | x :: xs -> if x = a then i else help (i+1) xs
    in
    help 0 b
;;

let rec replace_in_term t r = 
    match t with 
    | V v -> 
            let (pre, suf) = get_rev_prefix v 
            in
            V ((String.make (1+(index_in_list pre r)) '_') ^ suf)
    | Node (f, ts) -> Node (f, List.map (fun x -> replace_in_term x r) ts)

let rec replace_in_subst s r = 
    match s with 
    | [] -> []
    | (v, t) :: xs -> (v, (replace_in_term t r)) :: (replace_in_subst xs r);;

let rec embellish_substitution s = 
    let w = tree_to_list s 
    in
    let r = List.fold_left (fun x y -> match y with (name, t) -> union_of_list x (vars t) default_comp) [] w (*this is now a list of all var names in ocaml*)
    in
    let prefix_list = prefixes_of_string_list r
    in
    list_to_tree (replace_in_subst (tree_to_list s) prefix_list) default_comp
;;

let rec print_substitution_list_ l i = 
    match l with
    | [] -> Printf.printf ""
    | x :: xs -> Printf.printf "%d.\n" i; print_substitution (embellish_substitution x); Printf.printf ""; print_substitution_list_ xs (i + 1)
;;

let print_substitution_list l =
    if(List.length l = 0) then Printf.printf "False.\n\n" else
    (print_substitution_list_ l 1; Printf.printf "All solutions done.\n\n")
;;

(*prolog starts*)

let rec prepend_vars_term (t : term) : term = 
    match t with
    | V v -> (V ("_" ^ string_of_int(!global_state) ^ v))
    | Node(x, l) -> Node(x, (List.map prepend_vars_term l))
;;

let rec prepend_vars_ (clause_list : clause list) : (clause list) = 
    match clause_list with 
    | [] -> []
    | (x, l) :: cs -> ((prepend_vars_term x), (List.map prepend_vars_term l)) :: (prepend_vars_ cs)
;;

let rec restrict_substitution (l : variable list) (s : substitution) : substitution = (*this restricts the substitution to variables in l only - suppose this situation arises - substitution has X1 -> X where X1 is not in t, then we need to make sure that this situation doesn't happen*)
    let (v, sl) = ((list_to_tree l default_comp), (tree_to_list s)) in
    list_to_tree (List.filter (fun (varname, varterm) -> (find_bool v varname default_comp) || false) sl) default_comp
;;

let check_depth_le (x : string) (d : int) = (*note that this now works for depth = 1 only, which is nice*)
    if (String.length x <= d) then true 
    else if (String.sub x 0 (d+1)) = (String.make (d+1) '_') then false else true;;

let rec filter_substitution (d : int) (s : substitution) : (substitution) = 
    let w = (tree_to_list s)
    in 
    let rec work l acc = 
        match l with
        | [] -> acc
        | (x, t) :: xs -> 
                if(check_depth_le x d) then work xs ((x, t) :: acc)
                else work xs acc
    in
    list_to_tree (work w []) substitution_comparison

(*actually need to remove those variables whose first depth + 1 digits are _*)
let rec solve_goal (d : int) (goal : term) (cur_clause_list : clause list) (tot_clause_list : clause list) : (substitution list) = (*v is the list of variables we will restrict the substitution to have, at any given depth d this will contain vars with at most d _'s in the beginning, we need to set v to (vars goal) when we call this function somewhere*)
    match cur_clause_list with
    | [] -> []
    | c :: cs ->
            (*
                Printf.printf "Goal here: "; print_term goal;
                Printf.printf "Clause here: "; print_clause c
            *)
            match c with 
            | (x, pred_list) ->
                    try
                        (*Printf.printf "Finding mgu\n";*)
                        let s = (mgu goal x)
                        in
                        (
                        incr global_state;
                        let new_tot_clause_list = prepend_vars_ tot_clause_list
                        in
                        ((List.rev_map (filter_substitution (d)) (List.fold_left (fun subst_list_ term_ -> (List.fold_left (fun x subst_ -> ((fun t s -> (List.rev_map (subst_composition s) (solve_goal (d+1) (apply_substitution s t) new_tot_clause_list new_tot_clause_list))) term_ subst_) @ x ) [] subst_list_)) [s] pred_list))) @ (solve_goal (d) goal cs tot_clause_list))
                       
                    with
                    e -> (*Printf.printf "Unsuccessful with this\n";*) (solve_goal (d) goal cs tot_clause_list)
;;

let maptounit u = ();;

let solve_goal_list goal database = 
    let l = ((solve_goal 0 goal database database))
    in
   
    print_substitution_list l
;;

let rec solve_goal_multiple_ goal database = 
    let s = Leaf
    in
    let tot_clause_list = database 
    in
    let new_tot_clause_list = prepend_vars_ tot_clause_list
    in
    let pred_list = goal 
    in
    ((List.rev_map (filter_substitution (0)) (List.fold_left (fun subst_list_ term_ -> (List.fold_left (fun x subst_ -> ((fun t s -> (List.rev_map (subst_composition s) (solve_goal (1) (apply_substitution s t) new_tot_clause_list new_tot_clause_list))) term_ subst_) @ x ) [] subst_list_)) [s] pred_list)))

let rec solve_goal_multiple goal database = 
    (
    Printf.printf "Your query: ";
    print_term_list goal;
    Printf.printf "\n";
    let l = solve_goal_multiple_ goal database in
    print_substitution_list l
    )
;;

let rec solve_multiple_goals l database = 
    match l with 
    | [] -> ()
    | x :: xs -> solve_goal_multiple x database; solve_multiple_goals xs database
;;
