exception Impossible;;

type 'b tree = Leaf | Node of 'b tree * 'b * 'b tree * int;;

let ht t = match t with 
			|	Leaf -> 0
			|	Node (_, _, _, h) -> h;;

let make_node left data right = Node (left, data, right,  (max (ht right) (ht left)+1));;

(*comparison of a and b if a<b then returns -1 if equal 0 else 1*)

(*finding data n in a tree t*)
let rec find_bool t n comp = match t with 
			|	Leaf -> false
			|	Node (left, data, right, _)  -> 
                let res = comp n data in
				    if res < 0 then find_bool left n comp
				    else if res = 0 then true
				    else find_bool right n comp;;


let rec find_element t n comp = match t with
            |   Leaf -> raise Impossible
            |   Node (left, data, right, _) ->
                let res = comp n data in
                    if res < 0 then find_element left n comp
                    else if res = 0 then data
                    else find_element right n comp;;


let rotate_right node =
  match node with
  | Node (left, data, right, _) ->
      (match left with
      | Node (l1, d1, r1, _) ->
          let new_left = make_node r1 data right in
          make_node l1 d1 new_left
      | _ -> raise Impossible)
  | _ -> raise Impossible


let rotate_left node =
  match node with
  | Node (l2, d2, right, _) ->
      (match right with
      | Node (l1, d1, r1, _) ->
          make_node (make_node l2 d2 l1) d1 r1
      | _ -> raise Impossible)
  | _ -> raise Impossible



	let rec insert t x comp =
		let rec insert_helper t =
			match t with
			| Leaf -> Node (Leaf, x, Leaf, 1)
			| Node (left, data, right, _) ->
					let res = comp x data in
					if res = 0 then t
					else if res < 0 then
						let new_left = insert_helper left in
						balance new_left data right
					else
						let new_right = insert_helper right in
						balance left data new_right
		in
		insert_helper t
	
	and balance left data right =
		match left, right with
		| Leaf, _ -> make_node left data right
		| _, Leaf -> make_node left data right
		| Node (ll, ld, lr, _), Node (rl, rd, rr, _) ->
				let left_height = ht ll in
				let right_height = ht rr in
				if left_height > right_height + 1 then
					if ht ll >= ht lr then
						make_node ll ld (make_node lr data right)
					else
						rotate_right (make_node (rotate_left ll) ld (make_node lr data right))
				else if right_height > left_height + 1 then
					if ht rr >= ht rl then
						make_node (make_node left data rl) rd rr
					else
						rotate_left (make_node (make_node left data (rotate_right rr)) rd rl)
				else
					make_node left data right
	
	
(*finds the root of the tree*)
let data_at_node t =
  match t with
  | Leaf -> raise Impossible
  | Node (_, data, _, _) -> data


let rec list_to_tree l comp =
  let rec insert_list t lst =
    match lst with
    | [] -> t
    | hd :: tl -> insert_list (insert t hd comp) tl
  in
  insert_list Leaf l


let tree_to_list t =
	let rec tree_to_list_helper t acc =
		match t with
		| Leaf -> acc
		| Node (left, data, right, _) ->
				let acc' = data :: tree_to_list_helper right acc in
				tree_to_list_helper left acc'
	in
	tree_to_list_helper t []
	

	let default_comp x y =
		if x < y then -1
		else if x > y then 1
		else 0
	

		let range n =
			let rec range_helper n acc =
				if n = 0 then
					acc
				else
					range_helper (n - 1) (n :: acc)
			in
			range_helper n []
		

(*prints the tree - only for strings*)

(*let rec print_tree t =
  match t with
  | Leaf -> Printf.printf "Leaf\n"
  | Node (left, data, right, _) ->
      let print_child_data child =
        match child with
        | Leaf -> "Leaf"
        | Node (_, child_data, _, _) -> child_data
      in
      Printf.printf "%s -> %s, %s\n" data (print_child_data left) (print_child_data right);
      print_tree left;
      print_tree right

					
let range n =
	let rec range_helper acc n =
		if n = 0 then
			acc
		else
			range_helper (n :: acc) (n - 1)
	in
	range_helper [] n
			

let t = Leaf;;

print_tree (insert t "Hello");;
print_tree (List.fold_left insert t (range 30));;

let rec checkbalance t =
  match t with
  | Leaf -> true
  | Node (left, _, right, _) ->
      let height_diff = ht left - ht right in
      height_diff <= 1 && height_diff >= -1 && checkbalance left && checkbalance right


let rec pre_order_print t =
	let rec pre_order_helper t =
		match t with
		| Leaf -> ()
		| Node (left, data, right, _) ->
				print_string (data ^ " ");
				pre_order_helper left;
				pre_order_helper right
	in
	pre_order_helper t
			


list_tree (List.fold_left insert t (range 30)) [];;

let comp i j = 
  if i = j then 0 
  else if i < j then -1 
  else 1;;

List.sort comp (list_tree (List.fold_left insert t (range 30)) []);;
*)
