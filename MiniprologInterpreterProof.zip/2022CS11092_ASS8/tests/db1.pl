h(a).
g(X, Y) :- h(Y).
f(X) :- g(X, Y).
