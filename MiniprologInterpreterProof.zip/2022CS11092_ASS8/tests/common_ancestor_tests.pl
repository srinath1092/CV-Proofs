ca (X, X, 7).
ca (X, 13, 14).
ca (X, 13, 2).
ca(13, 14, X).
ca(Y, 12, X).
exit.
