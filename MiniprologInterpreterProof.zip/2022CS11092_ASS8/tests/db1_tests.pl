h(a).
f(a).
f(X).
g(a,a).
g(a, b).
exit.
