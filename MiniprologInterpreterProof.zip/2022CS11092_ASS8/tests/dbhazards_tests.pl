f(X).
g(X).
h(X).
i(X).
exit.
