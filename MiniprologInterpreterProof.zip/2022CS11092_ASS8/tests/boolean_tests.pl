xor(0, 1, X).
xor(A, B, C).
xor(0, 1, 0).
xnor(A, B, C).
xor(0, X, X).
exit.
