belongToGryffindor(X).
belongToSlytherin(X).
belongToHufflepuff(X).
belongToRavenclaw(X).
exit.
