numeral(succ(succ(succ(0)))).
gt(succ(succ(succ(succ(succ(0))))), X), add(Y, Y, X).
gt(succ(succ(succ(succ(succ(succ(succ(succ(succ(0))))))))), X), add(W, W, X), add(Y, Z, X), add(Y, Y, Z).
exit.
