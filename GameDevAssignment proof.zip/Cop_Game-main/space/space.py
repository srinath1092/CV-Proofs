import pygame,sys,random


# Initialize Pygame
pygame.init()




#loading the image of the player
player = pygame.image.load("player.png")

clock = pygame.time.Clock()
#making class for asteriods
class asteriods(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        choice = random.randint(1,4)
        if choice == 1:
            self.image = pygame.image.load("asteriod_1.png")
        if choice == 2:
            self.image = pygame.image.load("asteriod_2.png")
        if choice == 3:
            self.image = pygame.image.load("asteriod_3.png")
        if choice == 4:
            self.image = pygame.image.load("asteriod_4.png")
        self.rect = self.image.get_rect()
        choice = random.randint(1,4)
        self.rect.x=0
        self.rect.y=0 
        if choice == 1:    
            self.rect.x = 900
            self.rect.y = random.randint(-100,700)
        if choice == 2: 
            self.rect.x = -100
            self.rect.y = random.randint(-100,700)
        if choice == 3:
            self.rect.x = random.randint(-100,900)
            self.rect.y = 700
        if choice == 4:
            self.rect.x = random.randint(-100,900)
            self.rect.y = -100
        self.speed_x = 2
        self.speed_y = 2
    
    def update(self):
        global space_ship_direction
        global asteriods_group
        if self.rect.x > 1000:
            self.kill()
            asteriod = asteriods()
            asteriods_group.add(asteriod)
        if self.rect.x < -200:
            self.kill()
            asteriod = asteriods()
            asteriods_group.add(asteriod)
        if self.rect.y > 800:
            self.kill()
            asteriod = asteriods()
            asteriods_group.add(asteriod)
        if self.rect.y < -200:
            self.kill()
            asteriod = asteriods()
            asteriods_group.add(asteriod)
        if space_ship_direction == "up":
            self.rect.y += 4
            # self.rect.x -= 6
        if space_ship_direction == "down":
            self.rect.y-=4
            # self.rect.x -=6
        if space_ship_direction == "left":
            self.rect.x += 4
        if space_ship_direction == "right":
            self.rect.x -= 4


#making class for space ship
class space_ship(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # self.image = pygame.surface.Surface((50,50))
        self.image = pygame.image.load("player.png")
        self.image.fill((255,255,255))
        self.rect = self.image.get_rect()
        self.rect.x = 400
        self.rect.y = 300
        self.collisions = 0
        self.distance = 0
    def update(self):   
        self.rect.x = 400
        self.rect.y = 300
        global space_ship_direction
        if space_ship_direction == "up":
            self.image = pygame.transform.rotozoom(player,0,1)
        elif space_ship_direction == "down":
            self.image = pygame.transform.rotozoom(player,180,1)
        elif space_ship_direction == "left":
            self.image = pygame.transform.rotozoom(player,90,1)
            self.distance -=1
        elif space_ship_direction == "right":
            self.image = pygame.transform.rotozoom(player,270,1)
            self.distance += 1
        collisions = pygame.sprite.spritecollide(space_craft,asteriods_group,True)
        font = pygame.font.Font(None,36)
        text = font.render(f"Distance Remaining: {self.distance}",True,(255,255,255))
        screen.blit(text,(0,0))
        if collisions:
            self.collisions += 1
            print(self.collisions)
            if self.collisions == 3:
                pygame.quit()
                sys.exit()


# making a class for stars
class stars(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("star.jpg")
        self.rect = self.image.get_rect()
        # if space_ship_direction == "up":
        #     self.rect.x = random.randint(0,800)
        #     self.rect.y = 0
        # if space_ship_direction == "down":
        #     self.rect.x = random.randint(0,800)
        #     self.rect.y = 600
        # if space_ship_direction == "left":
        #     self.rect.x = 0
        #     self.rect.y = random.randint(0,600)
        # if space_ship_direction == "right":
        #     self.rect.x = 800
        #     self.rect.y = random.randint(0,600)
        choice = random.randint(1,4)
        if choice == 1:
            self.rect.x = random.randint(0,800)
            self.rect.y = 0
        if choice == 2:
            self.rect.x = random.randint(0,800)
            self.rect.y = 600
        if choice == 3:
            self.rect.x = 0
            self.rect.y = random.randint(0,600)
        if choice == 4:
            self.rect.x = 800
            self.rect.y = random.randint(0,600)
        
    
    def update(self):
        if space_ship_direction == "up":
            self.rect.y += 2
        if space_ship_direction == "down":
            self.rect.y -= 2
        if space_ship_direction == "left":
            self.rect.x += 2
        if space_ship_direction == "right":
            self.rect.x -= 2
        if self.rect.x > 800:
            self.kill()
            star = stars()
            stars_group.add(star)
        if self.rect.x < 0:
            self.kill()
            star = stars()
            stars_group.add(star)
        if self.rect.y > 600:
            self.kill()
            star = stars()
            stars_group.add(star)
        if self.rect.y < 0:
            self.kill()
            star = stars()
            stars_group.add(star)
       


# Set up the display
screen = pygame.display.set_mode((800,600))
pygame.display.set_caption("Space Invaders")
space_ship_direction = "up"

# adding the background image
bg_image = pygame.image.load("bg_1.jpeg")

# making of the group for asteriods
asteriods_group = pygame.sprite.Group()
for i in range(15):
    asteriod = asteriods()
    asteriods_group.add(asteriod)


# making of the group for space ship
space_craft_gp = pygame.sprite.Group()
space_craft = space_ship()
space_craft_gp.add(space_craft)

#making the group for stars
stars_group = pygame.sprite.Group() 
for i in range(35):
    star = stars()
    stars_group.add(star)


#making a function to display distance_remaining

while True :
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                space_ship_direction = "up"
            if event.key == pygame.K_DOWN:
                space_ship_direction = "down"
            if event.key == pygame.K_LEFT:
                space_ship_direction = "left"
            if event.key == pygame.K_RIGHT:
                space_ship_direction = "right"
    
    # screen.blit(bg_image,(0,0))
    screen.fill((0,0,0))
    stars_group.update()
    asteriods_group.update()
    stars_group.draw(screen)
    asteriods_group.draw(screen)
    space_craft_gp.update()
    space_craft_gp.draw(screen)
    pygame.display.update()
    clock.tick(60)