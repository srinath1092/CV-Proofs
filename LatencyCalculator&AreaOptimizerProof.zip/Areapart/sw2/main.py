import copy
import sys
import queue
import heapq

# Input File Paths
part = sys.argv[1]
circuit_path = sys.argv[2]
gate_delays_path = sys.argv[3]

# Output File Paths
maximum_delay_path = sys.argv[4]
if len(sys.argv) >= 6 and part == "B":
    maximum_area_path = sys.argv[5]

# Storage
primary_outputs = []
primary_inputs = []
internal_signals = []
graph = {}
gate_delays = {}
required_delays = {}
starting_points_part_b = []
max_delay = 0
area = 0
edges = []

if len(sys.argv) >= 5 and part == "B":
    with open(sys.argv[4], 'r') as file:
        content = file.read()

        try:
            max_delay = float(content)
        except ValueError:
            print('The file does not contain a valid number.')

gates = ["NAND2", "AND2", "NOR2", "OR2", "INV"]

for gate in gates:
    gate_delays[gate] = []


# Function to print graph
def print_graph(arr):
    for key in arr:
        print("Signal : ", key, end=" -> ")
        if arr[key].gate:
            print("GATE", end=": (")
            print(arr[key].gate.type, end=", ")
            print(arr[key].gate.delay, end=", ")
            print(arr[key].gate.area, end=")\n")
        for edge in arr[key].edges:
            print("(", end="")
            print(edge.destination.signal, end=",")
            print(edge.destination.indegree, end=",")
            print(edge.weight, end=")")
        print()


def print_heap(heap):
    print("Heap Start")

    for el in heap:
        print(el[1].signal, end=" ")
        print(el[0], end=" ")
        print(el[1].availableGate.type)
    print("Heap End\n\n")


def print_graph_all_ans(arr):
    for key in arr:
        print("Signal : ", key, end=" -> ")
        print("Ans : ", arr[key].ans, end=" ")
        print(arr[key].isDFFOutput, end="\n")


def print_gate_delays():
    for gate in gates:
        print(gate, end=" ")
        print(len(gate))
        for imp in gate_delays[gate]:
            print("(", end="")
            print(imp.type, end=",")
            print(imp.delay, end=",")
            print(imp.area, end=")\n")


# Utility Classes to build graph
class Gate:

    def __init__(self, type, delay, area):
        self.type = type
        self.delay = delay
        self.area = area


def compare_gate(node):
    return node.availableGate.area


class Edge:

    def __init__(self, signal, weight, type="NULL"):
        self.destination = signal
        self.weight = weight
        self.type = type


class Node:

    def __init__(self, signal, isDFFOutput=False, isDFFInput=False):
        self.ans = -1
        self.signal = signal
        self.indegree = 0
        self.edges = []
        self.isDFFOutput = isDFFOutput
        self.isDFFInput = isDFFInput
        self.gate = None
        self.availableGate = None

    def __lt__(self, other):
        # Define your custom comparison logic here
        # For example, if priority is based on some attribute, compare that attribute
        return self.signal < other.signal


class Node_Gate:
    def __init__(self, node, this_gate=None):
        self.node = node
        self.gate = this_gate
        self.gateNo = 0


# Get Gate Delays
with open(gate_delays_path, 'r') as file:
    for line in file:
        newLine = line.strip()

        words = newLine.split()
        if len(words) == 0 or words[0] == "//" or words[0] == " ":
            continue

        gate_type = words[1]
        gate_delays[gate_type].append(
            Gate(words[0], float(words[2]), float(words[3])))

# Sort The Gates according to gate delay (ascending order)
for gate in gates:
    gate_delays[gate].sort(key=lambda x: x.delay)


def get_output_delay(arr):
    q = queue.Queue()
    global max_delay

    for key in arr:
        if arr[key].isDFFOutput:
            arr[key].indegree = 0

        if arr[key].indegree == 0:
            q.put(arr[key])

    while not q.empty():
        curr = q.get()

        for edge in curr.edges:
            destination_node = edge.destination
            edge_weight = edge.weight

            curr.ans = 0 if curr.ans == -1 or curr.isDFFOutput else curr.ans
            destination_node.ans = 0 if destination_node.isDFFOutput else max(curr.ans + edge_weight,
                                                                              destination_node.ans)

            destination_node.indegree -= 1

            if destination_node.indegree == 0:
                q.put(destination_node)

            max_delay = max(max_delay, max(curr.ans, destination_node.ans))


def fix_circuit(pq, delay, child_node):
    global area

    while delay < 0:
        if abs(delay) < 1e-10:
            delay = 0
            break

        curr_node = heapq.heappop(pq)[1]
        curr_gate = curr_node.availableGate
        gate_type = curr_gate.type

        if curr_gate.delay == gate_delays[gate_type][1].delay:
            area += curr_gate.area - gate_delays[gate_type][2].area
            delay -= curr_gate.delay - gate_delays[gate_type][2].delay

            newGate = Gate(gate_type, gate_delays[gate_type][0].delay,
                           gate_delays[gate_type][0].area)
            curr_node.availableGate = newGate
            curr_node.gate = curr_gate

            heapq.heappush(pq, (compare_gate(curr_node), curr_node))
        elif curr_gate.delay == gate_delays[gate_type][0].delay:
            area += curr_gate.area - gate_delays[gate_type][1].area
            delay -= curr_gate.delay - gate_delays[gate_type][1].delay

            curr_node.availableGate = None
            curr_node.gate = curr_gate

    return delay


def dfs(node, pq, delay, nodes_in_path):
    global area
    global max_delay

    if node.isDFFOutput or node.signal in primary_inputs:
        return

    if node.availableGate:
        heapq.heappush(pq, (compare_gate(node), node))

    nodes_in_path.append(node)

    for child in node.edges:
        delay = max_delay
        for node_gate in nodes_in_path:
            delay -= node_gate.gate.delay if node_gate.gate else 0

        curr_delay = delay

        if child.destination.isDFFInput:
            continue

        if node.gate:
            pass
        else:
            newGate = Gate(child.type, gate_delays[child.type][1].delay,
                           gate_delays[child.type][1].area)
            area += gate_delays[child.type][2].area
            curr_delay -= gate_delays[child.type][2].delay

            node.gate = Gate(child.type, gate_delays[child.type][2].delay,
                             gate_delays[child.type][2].area)

            node.availableGate = newGate
            heapq.heappush(pq, (compare_gate(node), node))
        if curr_delay < 0:
            curr_delay = fix_circuit(pq, curr_delay, node)

        dfs(child.destination, pq, curr_delay, nodes_in_path)

    nodes_in_path.pop()
    for i in range(len(pq)):
        if pq[i] == node:
            pq.pop(i)


def get_optimized_area(arr):
    for node in starting_points_part_b:
        priority_queue = []
        nodes_in_path = []
        dfs(node, priority_queue, max_delay, nodes_in_path)

def dfs2(node, delay):
    if delay < 0:
        return False

    if node.isDFFOutput or node.signal in primary_inputs:
        return True

    for child in node.edges:
        if child.destination.isDFFInput:
            continue

        if not dfs2(child.destination, delay - node.gate.delay):
            return False

    return True


def try_all_combinations(arr, t, curr_area):
    if t == len(edges):
        global area

        for node in starting_points_part_b:
            if not dfs2(node, max_delay):
                return

        area = min(area, curr_area)
        return

    for gateNo in range(3):
        gateType = edges[t].gate
        edges[t].node.gate = Gate(gateType, gate_delays[gateType][gateNo].delay, gate_delays[gateType][gateNo].area)
        try_all_combinations(arr, t + 1, curr_area + gate_delays[gateType][gateNo].area)


# Create Graph from Circuit File
with open(circuit_path, 'r') as file:
    for line in file:
        newLine = line.strip()

        words = newLine.split()
        if len(words) == 0 or words[0] == "//" or words[0] == " ":
            continue

        if words[0] in ['PRIMARY_OUTPUTS', 'PRIMARY_INPUTS', 'INTERNAL_SIGNALS']:
            if words[0] == 'PRIMARY_OUTPUTS':
                for i in range(1, len(words)):
                    primary_outputs.append(words[i])

            if words[0] == 'PRIMARY_INPUTS':
                for i in range(1, len(words)):
                    primary_inputs.append(words[i])

            if words[0] == 'INTERNAL SIGNALS':
                for i in range(1, len(words)):
                    internal_signals.append(words[i])

            for i in range(1, len(words)):
                if words[i] not in graph:
                    graph[words[i]] = Node(words[i])

                if words[i] in required_delays:
                    graph[words[i]].ans = required_delays[words[i]]

        if words[0] not in [
            'PRIMARY_OUTPUTS', 'PRIMARY_INPUTS', 'INTERNAL_SIGNALS'
        ]:
            if part == "A":
                node_out = graph[words[len(words) -
                                       1]] if words[len(words) - 1] in graph else Node(
                    words[len(words) - 1])

                if words[len(words) - 1] not in graph:
                    graph[words[len(words) - 1]] = node_out

                if words[0] == "DFF":
                    node_out.isDFFOutput = True

                for i in range(1, len(words) - 1):
                    node_curr = graph[words[i]] if words[i] in graph else Node(words[i])
                    node_curr.edges.append(
                        Edge(node_out,
                             0 if words[0] == "DFF" else gate_delays[words[0]][0].delay))

                    node_out.indegree += 1

                    if words[i] not in graph:
                        graph[words[i]] = node_curr
            elif part == "B":
                node_out = graph[words[len(words) -
                                       1]] if words[len(words) - 1] in graph else Node(
                    words[len(words) - 1])

                if words[len(words) - 1] not in graph:
                    graph[words[len(words) - 1]] = node_out

                if words[len(words) - 1] in primary_outputs:
                    starting_points_part_b.append(node_out)

                if not words[0] == "DFF":
                    edges.append(Node_Gate(node_out, words[0]))

                if words[0] == "DFF":
                    node_out.isDFFOutput = True

                for i in range(1, len(words) - 1):

                    node_curr = graph[words[i]] if words[i] in graph else Node(words[i])
                    newEdge = Edge(node_curr, 0 if words[0] == "DFF" else gate_delays[words[0]][0].delay, words[0])
                    node_out.edges.append(newEdge)

                    node_curr.indegree += 1

                    if words[i] not in graph:
                        graph[words[i]] = node_curr

                    if (words[0] == "DFF") and node_curr not in starting_points_part_b:
                        starting_points_part_b.append(node_curr)
                        node_curr.ans = max_delay
                        node_curr.isDFFInput = True

if part == "A":
    get_output_delay(graph)
    for key in graph:
        graph[key].ans = 0 if graph[key].ans == -1 else graph[key].ans

    with open(maximum_delay_path, 'w') as file:
        file.write(str(max_delay))
elif part == "B":
    if len(edges) <= 13:
        area = float("inf")
        try_all_combinations(graph, 0, 0)
    else:
        get_optimized_area(graph)

    if area == float("inf"):
        area = "No circuit is possible for given delay constraint"

    with open(maximum_area_path, 'w') as file:
        file.write(str(area))
