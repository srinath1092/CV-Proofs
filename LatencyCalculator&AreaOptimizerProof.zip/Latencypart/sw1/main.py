import sys
import queue


# Helper Functions for debugging

# Function to print graph
def print_graph(arr):
    for key in arr:
        print("Signal : ", key, end=" -> ")
        for edge in arr[key].edges:
            print("(", end="")
            print(edge.destination.signal, end=",")
            print(edge.destination.indegree, end=",")
            print(edge.weight, end=")")
        print()


def print_graph_all_ans(arr):
    for key in arr:
        print("Signal : ", key, end=" -> ")
        print("Ans : ", arr[key].ans, end="")
        print()


def print_graph_required_ans(arr, graph, file_path):
    with open(file_path, 'a+') as file:
      for key in arr:
        file.write(str(key))
        file.write(" ")
        file.write(str(graph[key].ans))
        file.write("\n")
# End of Helper Functions


# Files paths given as command line arguments
part = sys.argv[1]
circuit_path = sys.argv[2]
gate_delays_path = sys.argv[3]
required_delays_path = None
if len(sys.argv) >= 5:
    required_delays_path = sys.argv[4]

# Arrays to store primary outputs and the graph for a circuit
primary_outputs = []
primary_inputs = []
graph = {}
gate_delays = {}
required_delays = {}

# Utility Classes to build graph
class Gate:
    def __init__(self, type, delay):
        self.type = type
        self.delay = delay


class Edge:
    def __init__(self, node, weight):
        self.destination = node
        self.weight = weight


class Node:
    def __init__(self, signal, indegree=0):
        self.ans = -1
        self.signal = signal
        self.indegree = indegree
        self.edges = []


# Get Required Output Delays
if required_delays_path:
    with open(required_delays_path, 'r') as file:
        for line in file:
            newLine = line.strip()

            words = newLine.split()
            if len(words) == 0 or words[0] == "//" or words[0] == " ":
                continue

            required_delays[words[0]] = float(words[1])


# Get Gate Delays
with open(gate_delays_path, 'r') as file:
    for line in file:
        newLine = line.strip()

        words = newLine.split()
        if len(words) == 0 or words[0] == "//" or words[0] == " ":
            continue

        gate_delays[words[0]] = float(words[1])

def get_output_delay(arr):
    q = queue.Queue()

    for key in arr:
        if arr[key].indegree == 0:
            q.put(arr[key])

    while not q.empty():
        curr = q.get()

        for edge in curr.edges:
            destination_node = edge.destination
            edge_weight = edge.weight

            curr_ans = 0 if curr.ans == -1 else curr.ans

            destination_node.ans = max(curr_ans + edge_weight, destination_node.ans)

            destination_node.indegree -= 1

            if destination_node.indegree == 0:
                q.put(destination_node)


def get_input_delay(arr):
    q = queue.Queue()

    for key in arr:
        if arr[key].indegree == 0:
            q.put(arr[key])

    while not q.empty():
        curr = q.get()

        for edge in curr.edges:
            destination_node = edge.destination
            edge_weight = edge.weight

            destination_node.ans = curr.ans - edge_weight if destination_node.ans == -1 else min(curr.ans - edge_weight, destination_node.ans)

            destination_node.indegree -= 1

            if destination_node.indegree == 0:
                q.put(destination_node)

  
# Read Contents of the file
with open(circuit_path, 'r') as file:
    for line in file:
        newLine = line.strip()

        words = newLine.split()
        if len(words) == 0 or words[0] == "//" or words[0] == " ":
            continue

        if words[0] in ['PRIMARY_OUTPUTS', 'PRIMARY_INPUTS', 'INTERNAL_SIGNALS']:
            if words[0] == 'PRIMARY_OUTPUTS':
                for i in range(1, len(words)):
                    primary_outputs.append(words[i])

            if words[0] == 'PRIMARY_INPUTS':
                for i in range(1, len(words)):
                    primary_inputs.append(words[i])

            for i in range(1, len(words)):
                if words[i] not in graph:
                    graph[words[i]] = Node(words[i])

                if words[i] in required_delays:
                    graph[words[i]].ans = required_delays[words[i]]

        if words[0] not in ['PRIMARY_OUTPUTS', 'PRIMARY_INPUTS', 'INTERNAL_SIGNALS']:
            if part == "A":
                node_out = graph[words[len(words) - 1]] if words[len(words) - 1] in graph else Node(
                    words[len(words) - 1])

                if words[len(words) - 1] not in graph:
                    graph[words[len(words) - 1]] = node_out

                for i in range(1, len(words) - 1):
                    node_curr = graph[words[i]] if words[i] in graph else Node(words[i])
                    node_curr.edges.append(Edge(node_out, float(gate_delays[words[0]])))

                    node_out.indegree += 1

                    if words[i] not in graph:
                        graph[words[i]] = node_curr

                
            else:
                node_out = graph[words[len(words) - 1]] if words[len(words) - 1] in graph else Node(
                    words[len(words) - 1])

                if words[len(words) - 1] not in graph:
                    graph[words[len(words) - 1]] = node_out

                for i in range(1, len(words) - 1):
                    node_curr = graph[words[i]] if words[i] in graph else Node(words[i])
                    node_out.edges.append(Edge(node_curr, float(gate_delays[words[0]])))

                    node_curr.indegree += 1

                    if words[i] not in graph:
                        graph[words[i]] = node_curr
            

if part == "A":
  get_output_delay(graph)
  for key in graph:
    if graph[key].ans < 0:
      graph[key].ans = 0
  print_graph_required_ans(primary_outputs, graph,"./ProjectFiles/output_delays.txt")
else:
  get_input_delay(graph)
  for key in graph:
      if graph[key].ans < 0:
        graph[key].ans = 0
  print_graph_required_ans(primary_inputs, graph, "./ProjectFiles/input_delays.txt")


  