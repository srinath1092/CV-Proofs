/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedint.h"
// #include <iostream>
// using namespace std;
UnlimitedInt ::UnlimitedInt()
{
    size = 0;
    sign = 1;
    capacity = 0;
    unlimited_int = NULL;
}
UnlimitedInt ::UnlimitedInt(string l)
{
    if (l[0] == '-')
    {
        sign = -1;
    }
    else
    {
        sign = 1;
    }
    capacity = l.length();
    if (sign >= 0)
    {

        unlimited_int = new int[capacity]();
        for (int p = capacity - 1; p >= 0; p--)
        {
            unlimited_int[p] = l[p] - '0';
            // cout << unlimited_int[p] << endl;
        }
        size = capacity;
    }

    if (sign < 0)
    {
        unlimited_int = new int[capacity - 1];
        size = capacity - 1;
        for (int i = 1; i < capacity; i++)
        {
            unlimited_int[i - 1] = l[i] - '0';
        }
    }
}
UnlimitedInt ::UnlimitedInt(int i)
{
    if (i < 0)
    {
        sign = -1;
    }
    else
    {
        sign = 1;
    }
    size = 0;
    i = abs(i);
    int t = i;
    while (t > 0)
    {
        t = t / 10;
        size++;
    }
    if (size == 0)
    {
        size = 1;
    }
    capacity = size;
    unlimited_int = new int[capacity];
    t = i;
    for (int p = size - 1; p >= 0; p--)
    {
        unlimited_int[p] = t % 10;
        t = t / 10;
    }
}
UnlimitedInt ::UnlimitedInt(int *ulimited_int, int cap, int sgn, int sz)
{

    this->capacity = cap;
    this->sign = sgn;
    this->size = sz;
    this->unlimited_int = new int[capacity];
    for (int i = 0; i < capacity; i++)
    {
        this->unlimited_int[i] = ulimited_int[i];
    }
}
UnlimitedInt ::~UnlimitedInt()
{
    delete[] unlimited_int;
}
int UnlimitedInt ::get_size()
{
    return size;
}
int *UnlimitedInt ::get_array()
{
    return unlimited_int;
}
int UnlimitedInt ::get_sign()
{
    return sign;
}
int UnlimitedInt ::get_capacity()
{
    return capacity;
}
UnlimitedInt *sum(UnlimitedInt *i1, UnlimitedInt *i2)
{
    int s1 = i1->get_size();
    int s2 = i2->get_size();
    int s = max(s1, s2) + 1;

    int *res = new int[s]{0};
    int carry = 0;
    int *u1 = i1->get_array();
    int *u2 = i2->get_array();

    for (int i = 0; i < s; i++)
    {
        int dig1 = (i < s1) ? u1[s1 - 1 - i] : 0;
        int dig2 = (i < s2) ? u2[s2 - 1 - i] : 0;
        int sum = dig1 + dig2 + carry;

        res[s - i - 1] = sum % 10;

        carry = sum / 10;
    }
    int size;
    if (res[0] == 0)
    {
        size = s - 1;
        for (int i = 0; i < s; i++)
        {
            res[i] = res[i + 1];
        }
    }
    else
    {
        size = s;
    }

    UnlimitedInt *i4 = new UnlimitedInt(res, s, i1->get_sign(), size);
    delete[] res;

    return i4;
}
bool small(UnlimitedInt *i1, UnlimitedInt *i2)
{
    int *u1 = i1->get_array();
    int *u2 = i2->get_array();
    int s1 = i1->get_size();
    int s2 = i2->get_size();
    if (s1 > s2)
        return false;
    if (s2 > s1)
        return true;
    for (int i = 0; i < s2; i++)
    {
        if (u1[i] > u2[i])
            return false;
        else if (u1[i] < u2[i])
            return true;
    }
    return false;
}
UnlimitedInt *diff(UnlimitedInt *i1, UnlimitedInt *i2)
{
    int s1 = i1->get_size();
    int s2 = i2->get_size();
    int s = max(s1, s2);
    int *res = new int[s]{0};
    int borrow = 0;
    int *u1 = i1->get_array();
    int *u2 = i2->get_array();
    for (int i = 0; i < s; i++)
    {
        int dig1 = (i < s1) ? u1[s1 - 1 - i] : 0;
        int dig2 = (i < s2) ? u2[s2 - i - 1] : 0;
        int di;
        if (small(i2, i1))
        {
            di = dig1 - dig2 - borrow;
        }
        else
        {
            di = dig2 - dig1 - borrow;
        }
        if (di < 0)
        {
            di += 10;
            borrow = 1;
        }
        else
        {
            borrow = 0;
        }
        res[s - 1 - i] = di;
        // cout << res[s - i - 1] << endl;
    }
    int size = s;
    int temp = 0;
    //cout<<"fg"<<endl;
    while (res[temp] == 0 && temp<s)
    {

        size--;
        temp++;
        // cout<<size<<endl;
        // cout<<"sz"<<endl;
    }
     if (size == 0)
    {
        size = 1;
    }
    int move = s - size;
    for (int i = 0; i < s - move; i++)
    {
        res[i] = res[i + move];
    }
   

    int sgn;
    if (small(i1, i2))
    {
        sgn = -(i1->get_sign());
    }
    else
    {
        sgn = i1->get_sign();
    }
    //cout<<"asd"<<endl;
    // for (int i = 0; i < size; i++)
    // {
    //     cout<<"poi"<<endl;
    //     cout << res[i] << endl;
    // }
    UnlimitedInt *i3;
    i3 = new UnlimitedInt(res, s, sgn, size);
    delete[] res;

    return i3;
}
UnlimitedInt *UnlimitedInt::add(UnlimitedInt *i1, UnlimitedInt *i2)
{
    UnlimitedInt *i3;
    if (i1->get_sign() == 1 && i2->get_sign() == 1)
    {
        i3 = sum(i1, i2);
    }
    if (i1->get_sign() == -1 && i2->get_sign() == -1)
    {
        i3 = sum(i1, i2);
    }
    if (i1->get_sign() == 1 && i2->get_sign() == -1)
    {
        i3 = diff(i1, i2);
    }
    if (i1->get_sign() == -1 && i2->get_sign() == 1)
    {
        i3 = diff(i1, i2);
    }
    return i3;
}
UnlimitedInt *UnlimitedInt ::sub(UnlimitedInt *i1, UnlimitedInt *i2)
{
    UnlimitedInt *i3;
    if (i1->get_sign() == 1 && i2->get_sign() == 1)
    {
        i3 = diff(i1, i2);
    }
    if (i1->get_sign() == -1 && i2->get_sign() == -1)
    {
        i3 = diff(i1, i2);
    }
    if (i1->get_sign() == 1 && i2->get_sign() == -1)
    {
        i3 = sum(i1, i2);
    }
    if (i1->get_sign() == -1 && i2->get_sign() == 1)
    {
        i3 = sum(i1, i2);
    }
    return i3;
}

UnlimitedInt *UnlimitedInt ::mul(UnlimitedInt *i1, UnlimitedInt *i2)
{
    int sgn = i1->get_sign() * i2->get_sign();

    int s1 = i1->get_size();
    int s2 = i2->get_size();
    int s = s1 + s2;
    int *u1 = i1->get_array();
    int *u2 = i2->get_array();
    // cout << "h" << endl;
    UnlimitedInt *i3 = new UnlimitedInt(0);
    // cout << "j" << endl;
    UnlimitedInt *prod[10];
    // cout << "k" << endl;
    prod[0] = new UnlimitedInt(0);
    for (int i = 1; i < 10; i++)
    {
        if (i == 1)
        {
            prod[i] = i1;
        }

        else
        {
            prod[i] = add(prod[i - 1], i1);
        }
    }
    // for (int i = 1; i < 10; i++)
    // {
    //     for (int j = 0; j < prod[i]->get_size(); j++)
    //     {
    //         cout << prod[i]->get_array()[j];
    //     }
    //     cout << endl;
    // }

    // cout << "n" << endl;
    UnlimitedInt *partsum[s2];
    for (int i = 0; i < s2; i++)
    {
        partsum[i] = new UnlimitedInt(0);
    }
    int *u11 = partsum[0]->get_array();
    // cout << u11[0] << endl;

    // cout << "z" << endl;
    for (int i = s2 - 1; i >= 0; i--)
    {
        int dig2 = u2[i];

        int shift = s2 - 1 - i;
        int *res = new int[s]{0};
        // cout << "kl" << dig2 << endl;
        int pro = prod[dig2]->get_size();
        // cout << "kj" << endl;
        int *arr = new int[pro + shift]{0};
        // cout << "x" << endl;
        for (int j = 0; j < pro; j++)
        {
            // cout << "a" << endl;
            arr[j] = prod[dig2]->unlimited_int[j];
            // cout << arr[j] << endl;
        }

        // cout << "c" << endl;
        int *temp = partsum[i]->get_array();
        // cout << "v" << endl;
        temp = arr;
        partsum[i] = new UnlimitedInt(arr, pro + shift, 1, pro + shift);

        // for (int k = s2 - 1; k >= 0; k--)
        // {
        //     for (int z = 0; z < partsum[k]->get_size(); z++)
        //     {
        //         cout << partsum[k]->get_array()[z];
        //     }
        // }
        // cout << "v" << endl;
        i3 = add(i3, partsum[i]);
        // cout << "v" << endl;
    }
    i3->sign = sgn;
    // for (int i = 0; i < 10; i++)
    // {
    //     delete prod[i];
    // }

    // for (int i = 0; i < s2; i++)
    // {
    //     delete partsum[i];
    // }
    return i3;
}
UnlimitedInt *shift(int sft, UnlimitedInt *i1)
{
    if (sft < 0)
    {
        return NULL;
    }
    int sgn1 = i1->get_sign();
    int s1 = i1->get_size();
    int *u1 = i1->get_array();
    int newsize = s1 + sft;
    int *newdigits = new int[newsize];
    for (int i = 0; i < s1; i++)
    {
        newdigits[i] = u1[i];
    }
    for (int i = s1; i < newsize; i++)
    {
        newdigits[i] = 0;
    }
    delete[] u1;
    i1 = new UnlimitedInt(newdigits, newsize, sgn1, newsize);
    return i1;
}
UnlimitedInt *adddgt(int dgt, UnlimitedInt *i1)
{
    int sgn1 = i1->get_sign();
    int s1 = i1->get_size();
    int *u1 = i1->get_array();
    int newsize = s1 + 1;
    int *newdigits = new int[newsize];
    newdigits[0] = dgt;
    for (int i = 1; i < s1 + 1; i++)
    {
        newdigits[i] = u1[i - 1];
    }
    delete[] u1;
    i1 = new UnlimitedInt(newdigits, newsize, sgn1, newsize);
    return i1;
}
UnlimitedInt *UnlimitedInt ::div(UnlimitedInt *i1, UnlimitedInt *i2)
{
    int s1 = i1->get_size();
    int s2 = i2->get_size();
    int sgn = i1->get_sign() * i2->get_sign();
    if (s1 < s2)
    {
        if (sgn >= 0)
        {
            return new UnlimitedInt(0);
        }
        else
        {
            return new UnlimitedInt(-1);
        }
    }
    UnlimitedInt *q = new UnlimitedInt(0);
    int t = s1 - s2;

    UnlimitedInt *t2 = new UnlimitedInt(i2->get_array(), i2->get_capacity(), 1, i2->get_size());
    UnlimitedInt *t1 = new UnlimitedInt(i1->get_array(), i1->get_capacity(), 1, i1->get_size());
    while (t >= 0)
    {
        int *temp = new int[t2->get_size() + t]{0};
        for (int i = 0; i < t2->get_size(); i++)
        {
            temp[i] = t2->get_array()[i];
        }

        UnlimitedInt *t3 = new UnlimitedInt(temp, i2->get_capacity() + t, 1, i2->get_size() + t);

        while (!small(t1, t3))
        {
            t1 = sub(t1, t3);
            int *ten_power = new int[t + 1]{0};
            ten_power[0] = 1;
            UnlimitedInt *power = new UnlimitedInt(ten_power, t + 1, 1, t + 1);
            q = add(q, power);
        }
        t--;
    }
    if (sgn >= 0)
    {
        return q;
    }
    if (sgn < 0)
    {
        int *q1 = q->get_array();
        int sq = q->get_size();
        q = new UnlimitedInt(q1, sq, -1, sq);
        UnlimitedInt* se = mul(i2,q);
        UnlimitedInt* rem = sub(i1,se);
        bool checkq;
        
         
        //  cout<<rem->get_size()<<endl;
        for(int i=0;i<rem->get_size();i++){
            
            if(rem->get_array()[i]==0){checkq = true;
            }
            else{
                checkq = false;
                
                break;
            }
        }
        if(checkq){
        //     int *q1 = q->get_array();
        // int sq = q->get_size();
        // q = new UnlimitedInt(q1, sq, -1, sq);
            return q;
        }else{
        UnlimitedInt *a = new UnlimitedInt(1);
        UnlimitedInt*temp = new UnlimitedInt(q->get_array(),q->get_capacity(),1,q->get_size());
        temp = add(temp, a);
        int *q1 = q->get_array();
        int sq = q->get_size();
        temp  = new UnlimitedInt(temp->get_array(), temp->get_capacity(), -1, temp->get_size());
        //delete a;
        return temp;
        }
    }
    return q;
}
UnlimitedInt *UnlimitedInt ::mod(UnlimitedInt *i1, UnlimitedInt *i2)
{
    //cout<<"w"<<endl;

    UnlimitedInt *q = div(i1, i2);
    //cout<<"e"<<endl;
    UnlimitedInt *temp = mul(q, i2);
    //cout<<"r"<<endl;
    UnlimitedInt *m = sub(i1, temp);
    //cout<<"t"<<endl;
    return m;
}

//     UnlimitedInt *q = div(i1, i2);
//     UnlimitedInt *temp = mul(q, i2);
//     UnlimitedInt *m = sub(temp, i1);
//     temp = new UnlimitedInt(m->get_array(), m->get_capacity(), m->get_sign() * -1, m->get_size());
//     return temp;
// }
// return temp;

string UnlimitedInt::to_string()
{
    string s = "";
    if (sign < 0)
    {
        s = s + "-";
    }
    for (int i = 0; i < size; i++)
    {
        s = s + (std ::to_string(unlimited_int[i]));
    }
    return s;
}
// int main()
// {
//     UnlimitedInt *i1 = new UnlimitedInt("400");
//     UnlimitedInt *i2 = new UnlimitedInt("-19");

//     UnlimitedInt *i3 = UnlimitedInt::mod(i1, i2);
//     // UnlimitedInt*i4 = new UnlimitedInt("8");
//     // UnlimitedInt* mul = UnlimitedInt :: sub(i4,i3);

//     // // int *u89 = i3->get_array();
//     // int s89 = i3->get_size();
//     // cout << s89 << endl;
//     // for (int i = 0; i < i1->get_size(); i++)
//     // {
//     //     cout << i1->get_array()[i] << endl;
//     // }
//     // cout << i1->get_size() << endl;
//     // cout << i3->get_size() << endl;
//     // cout<<"resdfg"<<endl;
//     // for (int i = 0; i < i3->get_size(); i++)
//     // {
//     //     cout << i3->get_array()[i];
//     // }
//     //  cout << i3->get_sign() << endl;
//     // cout<<"gf"<<endl;
//     // cout<<i3->get_size()<<endl;
//     // cout << i3->get_sign() << endl;
//     // cout << i3->get_size() << endl;
//     return 0;
// }