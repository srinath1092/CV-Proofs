/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "evaluator.h"
// #include<iostream>
Evaluator ::Evaluator()
{
    symtable = new SymbolTable();
    expr_trees = vector<ExprTreeNode *>();
}
// void deleteTree(ExprTreeNode *node)
// {
//     if (node != nullptr)
//     {
//         deleteTree(node->left);
//         deleteTree(node->right);
//         delete node;
//     }
//     return;
// }
Evaluator ::~Evaluator()
{
    //cout<<"deev"<<endl;
    delete symtable;
    //cout<<"delsym"<<endl;
    int sez = expr_trees.size();
    //cout<<sez<<endl;
    for (int p = 0; p < sez; p++)
    {
        //cout<<expr_trees[p]->left->type<<endl;
        delete (expr_trees[p]);
    }
    //cout<<"delexp"<<endl;
    expr_trees.clear();
    //cout<<"delxit"<<endl;
}
void Evaluator ::parse(vector<string> code)
{
    vector<ExprTreeNode *> nStack;
    nStack.push_back(new ExprTreeNode());
    int codesize = code.size();
    
    string &toke = code[0];
    ExprTreeNode *temp1 = new ExprTreeNode();
    nStack.back()->left = temp1;
    nStack.push_back(temp1);
    //cout<<nStack.size()<<endl;
    nStack.back()->type = "VAR";
    nStack.back()->id = toke;
    nStack.pop_back();
    nStack.back()->type = "ASSIGN";
   //cout<< nStack.back()->type<<endl;
   ExprTreeNode*temp2 = new ExprTreeNode();
    nStack.back()->right  = temp2;
    //cout<<nStack.back()->right->type<<endl;
    nStack.push_back(temp2);
    //cout<< nStack.back()->type<<endl;
    

    for (int p = 2; p < codesize; p++)
    {
       //cout<<code[p]<<endl;
        string &token = code[p];
        ExprTreeNode *temp = new ExprTreeNode();
        if (token == "(")
        {
            if (!nStack.empty())
            {
                
                nStack.back()->left = temp;
                //cout<<nStack.size()<<endl;
                //cout<<nStack.back()->type<<"ert"<<endl;
            }
            nStack.push_back(temp);
           //cout<<nStack.size()<<endl;
            //cout<<nStack.back()->type<<endl;
            
        }
        else if (token == "+" || token == "-" || token == "*" || token == "/")
        {
            
            if (!nStack.empty())
            {
                if (token == "+")
                {
                    //cout<<nStack[nStack.size()-2]->type<<"asdf"<<endl;
                    //cout<<nStack[nStack.size()-2]->left->type<<"asdf"<<endl;
                    //cout<<nStack.back()->type<<endl;
                    nStack.back()->type = "ADD";
                     //cout<<nStack.back()->type<<endl;
                     //cout<<nStack.size()<<endl;
                    //cout<<nStack[nStack.size()-2]->left->type<<"as"<<endl;
                    
                }
                if (token == "-")
                {
                    nStack.back()->type = "SUB";
                }
                if (token == "*")
                {
                    nStack.back()->type = "MUL";
                }
                if (token == "/")
                {
                    nStack.back()->type = "DIV";
                }
                nStack.back()->right = temp;
                 //cout<<nStack.back()->type<<"stacksz"<<endl;
                 //cout<<nStack.back()->left->type<<endl;
            }
            nStack.push_back(temp);
            //cout<<nStack.back()->type<<"asddfghjkhgfdg"<<endl;
        }
        else if (token == ")")
        {
            //cout<<nStack.size()<<"befor opop"<<endl;
            nStack.pop_back();
            
        }
        else if (token == "=")
        {
            if (!nStack.empty())
            {//cout<<nStack.back()->type<<"befass"<<endl;
                nStack.back()->type = "ASSIGN";
              //cout<<nStack.back()->type<<"afass"<<endl ; 
                nStack.back()->right = temp;
                //cout<<nStack.back()->right->type<<"afass"<<endl;
            }
            nStack.push_back(temp);

        }
        else
        {
            
            if ((token[0] - '0' >= 0 && token[0] - '0' <= 9) || token[0] == '-')
            {
            
            //cout<<"operand"<<endl;
                UnlimitedInt *i1 = new UnlimitedInt(1);
                UnlimitedInt *i2 = new UnlimitedInt(token);
                UnlimitedRational *v = new UnlimitedRational(i2, i1);
                
                nStack.back()->type = "VAL";
                nStack.back()->val = v;
            
                //cout<<nStack.back()->type<<" "<<nStack.size()<<endl;
                
            }
            else
            {
                nStack.back()->type = "VAR";
                nStack.back()->id = token;
                
            }
            nStack.pop_back();
            //cout<<nStack.back()->type<<"after pop"<<endl;
        }
    }
    //cout<<"beforexpr"<<nStack.size()<<endl;
    
    if (!nStack.empty())
    {
         //cout<<"red"<<endl;
        expr_trees.push_back(nStack.back());
      //  cout<<"yel"<<endl;
    // cout<<expr_trees.size()<<"sizeex"<<endl;
        
    }
    // for (int p = 0; p < nStack.size(); p++)
    // {
    //     cout<<"del"<<p<<endl;
    //     delete nStack[p];
    // }
    // cout<<"end"<<endl;
}
UnlimitedRational* evalrec(ExprTreeNode *node, SymbolTable *symtable)
{
    //cout<<node->type<<"enteer"<<endl;
    //if(!node->left){//cout<<"wer"<<endl;}
    // if(node->left){
    // //cout<<node->left->type<<"ergrrg"<<endl;
    // }if(node->right){
    // //cout<<node->right->type<<"ertrewg"<<endl;}
    // //cout<<"wr"<<endl;
    ExprTreeNode *temp = node;
    if (node->type == "")
    {
        // cout<<"nulreturn"<<endl;
        return new UnlimitedRational();
    }
    if(node->left){
    UnlimitedRational*e = evalrec(node->left, symtable);
    }
    // cout<<"left"<<endl;
    if(node->right){
    UnlimitedRational*d = evalrec(node->right, symtable);
    }
    // cout<<"right"<<endl;
    if (node->type == "VAL")
    {
        //cout<<"val"<<endl;
        node->evaluated_value = node->val;
        //cout<<"ass"<<endl;
        return node->evaluated_value;
    }
    if (node->type == "VAR")
    {
        //cout<<"var"<<endl;
        UnlimitedInt*p1 = symtable->search(node->id)->get_p();
        UnlimitedInt* q1 = symtable->search(node->id)->get_q();
      //  cout<<"qw"<<endl;
        node->evaluated_value   = new UnlimitedRational(p1,q1);
    }
    if (node->type == "ADD" || node->type == "SUB" || node->type == "DIV" || node->type == "MUL")
    {
        //cout<<"ert"<<endl;
        UnlimitedRational *r = node->right->evaluated_value;
        //cout<<"enter"<<endl;
        UnlimitedRational *l = node->left->evaluated_value;
        if (node->type == "ADD")
        {
            //cout<<"res"<<endl;
            node->evaluated_value = UnlimitedRational::add(l, r);
            return node->evaluated_value;
        }
        else if (node->type == "SUB")
        {
            node->evaluated_value = UnlimitedRational::sub(l, r);
        }
        else if (node->type == "MUL")
        {
            node->evaluated_value = UnlimitedRational::mul(l, r);
        }
        else if (node->type == "DIV")
        {
            node->evaluated_value = UnlimitedRational ::div(l, r);
        }
    }
    if (node->type == "ASSIGN")
    {
        UnlimitedRational*tmp1 = new UnlimitedRational(node->right->evaluated_value->get_p(),node->right->evaluated_value->get_q());
        node->left->evaluated_value = tmp1;
        //cout<<node->left->evaluated_value->get_frac_str()<<endl;
    }
   // cout<<temp->left->type<<"bass"<<endl;
    symtable->insert(temp->left->id, temp->left->evaluated_value);
    return new UnlimitedRational();
}
void Evaluator ::eval()
{
   // cout<<"enter"<<endl;
    if (expr_trees.empty())
    {
        return;
    }
    // cout<<"enter"<<endl;
    // cout<<expr_trees.size()<<endl;
   UnlimitedRational*res =  evalrec(expr_trees.back()->right, symtable);
   //cout<<"sdsdsds"<<endl;
   //cout<<res->get_frac_str()<<endl;
   expr_trees.back()->left->evaluated_value = new UnlimitedRational(res->get_p(),res->get_q());
   //cout<<expr_trees.back()->left->evaluated_value->get_frac_str()<<endl;
   //cout<<"erd"<<endl;
   symtable->insert(expr_trees.back()->left->id, expr_trees.back()->left->evaluated_value);
   //cout<<"nerd"<<endl;
   return;


}
// void evalrec(ExprTreeNode *node, SymbolTable *symtable)
// {
//     ExprTreeNode *temp = node;
//     if (node == NULL)
//     {
//         return;
//     }
//     evalrec(node->left, symtable);
//     evalrec(node->right, symtable);
//     if (node->type == "VAL")
//     {
//         node->evaluated_value = node->val;
//     }
//     if (node->type == "VAR")
//     {
//         node->evaluated_value = symtable->search(node->id);
//     }
//     if (node->type == "ADD" || node->type == "SUB" || node->type == "DIV" || node->type == "MUL")
//     {
//         UnlimitedRational *r = node->right->evaluated_value;
//         UnlimitedRational *l = node->left->evaluated_value;
//         if (node->type == "ADD")
//         {
//             node->evaluated_value = UnlimitedRational::add(l, r);
//         }
//         else if (node->type == "SUB")
//         {
//             node->evaluated_value = UnlimitedRational::sub(l, r);
//         }
//         else if (node->type == "MUL")
//         {
//             node->evaluated_value = UnlimitedRational::mul(l, r);
//         }
//         else if (node->type == "DIV")
//         {
//             node->evaluated_value = UnlimitedRational ::div(l, r);
//         }
//     }
//     if (node->type == "ASSIGN")
//     {
//         node->left->evaluated_value = node->right->evaluated_value;
//     }
//     symtable->insert(temp->left->id, temp->left->evaluated_value);
// }
//  #include <iostream>
// #include <queue>

// Add this function to the Evaluator class
// void Evaluator::levelOrderTraversal()
// {
//     if (expr_trees.empty())
//     {
//         std::cout << "Expression tree is empty." << std::endl;
//         return;
//     }

//     std::queue<ExprTreeNode *> q;
//     q.push(expr_trees.back());

//     while (!q.empty())
//     {
//         ExprTreeNode *currentNode = q.front();
//         q.pop();

//         // Print the node's information (e.g., type, evaluated value, etc.)
//         std::cout << "Node Type: " << currentNode->type << ", Evaluated Value: " << currentNode->evaluated_value << std::endl;

//         if (currentNode->left)
//             q.push(currentNode->left);

//         if (currentNode->right)
//             q.push(currentNode->right);
//     }
// }

// int main()
// {
//     Evaluator evaluator;
    
//     // Example code to parse
//     std::vector<std::string> code ={"x","=","(","5","+","3",")"};
    
//     // Parse the code
//     evaluator.parse(code);
//     ExprTreeNode* t=evaluator.expr_trees.back();
//     // cout<<t->type<<endl;
//     // cout<<t->left->id<<endl;
//     // // // Evaluate the expression
//     evaluator.eval();
//     //cout<<"xit"<<endl;
//     //cout<<t->left->type<<endl;
//     //cout<<t->left->evaluated_value->get_frac_str()<<endl;
//     //cout<<"ebd"<<endl;
//     // Perform level order traversal and print the nodes
//     //evaluator.levelOrderTraversal();
    
//     return 0;
// }
