/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "exprtreenode.h"
// #include <iostream>
ExprTreeNode ::ExprTreeNode()
{
    type = "";
    id="";
    val = NULL;
    evaluated_value = NULL;
    left = NULL;
    right = NULL;
}
ExprTreeNode ::ExprTreeNode(string t, UnlimitedInt *v)
{
    type = t;
    UnlimitedInt *i1 = new UnlimitedInt(1);
    UnlimitedRational *i2 = new UnlimitedRational(v, i1);
    if (t == "VAL")
    {
        val = i2;
    }
    else
    {
        val = NULL;
    }
    evaluated_value = NULL;
    left = NULL;
    right = NULL;
    id ="";
}
ExprTreeNode ::ExprTreeNode(string t, UnlimitedRational *v)
{
    type = t;
    if (t == "VAL")
    {
        val = v;
    }
    else
    {
        val = NULL;
    }
    evaluated_value = NULL;
    left = NULL;
    right = NULL;
}
ExprTreeNode ::~ExprTreeNode()
{
    if(right!=nullptr){delete right;}
     //std:: cout<<"delexr"<<endl;}
   
    if(left!=nullptr){delete left;}
     //std:: cout<<"delexl"<<endl;}
    
    if(type!="VAR"||type !="ASSIGN"){delete evaluated_value;}
     //std:: cout<<"delexvar"<<endl;}
    
    if(val){delete val;}
     //std:: cout<<"delexval"<<endl;}
}
