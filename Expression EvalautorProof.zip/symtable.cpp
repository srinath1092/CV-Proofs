/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
// #include<iostream>
// using namespace std;
SymbolTable ::SymbolTable()
{
    size = 0;
    root = NULL;
}
// void deleteTree(SymEntry *node)
// {
//     if (node != nullptr)
//     {
//         deleteTree(node->left);
//         deleteTree(node->right);
//         delete node;
//     }
//     return;
// // }
SymbolTable ::~SymbolTable()
{
    size = 0;
    if(root){
    delete root;
    }
    
}
SymEntry *ins(SymEntry *node, UnlimitedRational *i, string l)
{
    if (node == NULL)
    {
        return new SymEntry(l, i);
    }
    if (l < node->key)
    {
        node->left = ins(node->left, i, l);
    }
    else if (l > node->key)
    {
        node->right = ins(node->right, i, l);
    }
    return node;
}
void SymbolTable ::insert(string k, UnlimitedRational *v)
{
    root = ins(root, v, k);
    size = size + 1;
}
// SymEntry *ins(SymEntry *node, UnlimitedRational *i, string l)
// {
//     if (node == NULL)
//     {
//         return new SymEntry(l, i);
//     }
//     if (l < node->key)
//     {
//         node->left = ins(node->left, i, l);
//     }
//     else if (l > node->key)
//     {
//         node->right = ins(node->right, i, l);
//     }
//     return node;
// }
void rem(SymEntry *node, string l)
 {
//     if (node == NULL)
//     {
//         return ;
//     }
//     cout<<"as"<<endl;
//     if (l < node->key)
//     {
//         cout<<"ad"<<endl;
//          rem(node->left, l);
//     }
//     else if (l > node->key)
//     {
//         cout<<"asd"<<endl;
//          rem(node->right, l);
//     }
//     else
//     {
//         if(node->left==NULL && node->right==NULL){
//             cout<<"wert"<<endl;
//             delete node->val;
//             delete node;
            
//         }
//         if (node->left == NULL)
//         {
//             cout<<"adfg"<<endl;
//             SymEntry *tmp = node->right;
//             node->val = tmp->val;
//             delete node->val;
//             delete node;
            
//         }
//         if (node->right == NULL)
//         {
//             cout<<"qer"<<endl;
//             SymEntry *tmp = node->left;
//             delete node->val;
//             delete node;
            
//         }
//         cout<<"asdfghhj"<<endl;
//         SymEntry *mright = node->right;
//         while (mright->left != NULL)
//         {
//             mright = mright->left;
//             cout<<"kl"<<endl;
//         }
//         node->val = mright->val;
//         node->key = mright->key;
//         cout<<"rem"<<endl;
//         rem(node->right, mright->key);
//         cout<<"remen"<<endl;
//     }
//     cout<<"gh"<<endl;
    return ;
}
void SymbolTable ::remove(string k)
{
    //cout<<"aa"<<endl;
    rem(root, k);
    //cout<<"a"<<endl;
    size = size - 1;
}
// SymEntry *rem(SymEntry *node, string l)
// {
//     if (node = NULL)
//     {
//         return NULL;
//     }
//     if (l < node->key)
//     {
//         node = rem(node->left, l);
//     }
//     else if (l > node->key)
//     {
//         node = rem(node->right, l);
//     }
//     else
//     {
//         if (node->left == NULL)
//         {
//             SymEntry *tmp = node->right;
//             delete node->val;
//             delete node;
//             return tmp;
//         }
//         if (node->right == NULL)
//         {
//             SymEntry *tmp = node->left;
//             delete node->val;
//             delete node;
//             return tmp;
//         }
//         SymEntry *mright = node->right;
//         while (mright->left != NULL)
//         {
//             mright = mright->left;
//         }
//         node->val = mright->val;
//         node->key = mright->key;
//         node->right = rem(node->right, mright->key);
//     }
//     return node;
// }
UnlimitedRational *srch(SymEntry *node, string l)
{
    if (node == nullptr || l == node->key)
    {
        //cout<<"ert"<<endl;
        if (node == NULL)
        {
           // cout<<"fg"<<endl;
            return nullptr;
        }
        return node->val;
    }

    if (l < node->key)
    {
       // cout<<"ag"<<endl;
        return srch(node->left, l);
    }
    else
    {
        //cout<<"as"<<endl;
        return srch(node->right, l);
    }
}
UnlimitedRational *SymbolTable::search(string l)
{
   // cout<<"symenter"<<endl;
    return srch(root, l);
}
// UnlimitedRational *srch(SymEntry *node, string l)
// {
//     if (node == nullptr || l == node->key)
//     {
//         if (node == NULL)
//         {
//             return nullptr;
//         }
//         return node->val;
//     }

//     if (l < node->key)
//     {
//         return srch(node->left, l);
//     }
//     else
//     {
//         return srch(node->right, l);
//     }
// }

int SymbolTable::get_size()
{
    return size;
}

SymEntry *SymbolTable::get_root()
{
    return root;
}

// int main(){
//     SymbolTable a;
//     UnlimitedInt*num = new UnlimitedInt("5");
//     UnlimitedInt*den = new UnlimitedInt("9");
//     UnlimitedRational*p = new UnlimitedRational(num,den);
//     UnlimitedInt*num1 = new UnlimitedInt("6");
//     UnlimitedInt*den1 = new UnlimitedInt("11");
//     UnlimitedRational*p1 = new UnlimitedRational(num1,den1);
//     a.insert("x",p);
//     a.insert("y",p1);
//     // cout<<a.get_size()<<endl;
//     // cout<<a.get_root()->val->get_frac_str()<<" "<<a.get_root()->key<<endl;
//     // cout<<a.search("y")->get_frac_str()<<endl;
//      cout<<a.get_root()->right->key<<endl;
//     //a.remove("y");
//     //cout<<a.get_size()<<endl;
//     //a.~SymbolTable();
//     delete num;
//     delete den;
//    // delete p;
//     delete num1;
//     delete den1;
//     //delete p1;
// }