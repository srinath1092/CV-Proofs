/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedrational.h"
// #include <iostream>
// using namespace std;
UnlimitedInt *gcd(UnlimitedInt *i1, UnlimitedInt *i2)
{
    
    
    int s2 = i2->get_size();
    bool check;
    for (int i = 0; i < s2; i++)
    {
        if (i2->get_array()[i] == 0)
        {
            check = true;
        }
        else
        {
            check = false;
            break;
        }
    }
    
    if (check)
    {
        return i1;
    }
    
    return gcd(i2, UnlimitedInt::mod(i1, i2));
}

UnlimitedRational ::UnlimitedRational()
{
    p = new UnlimitedInt();
    q = new UnlimitedInt();
}
UnlimitedRational ::UnlimitedRational(UnlimitedInt *num, UnlimitedInt *den)
{
    
    // p = new UnlimitedInt(num->get_array(), num->get_capacity(), num->get_sign(), num->get_size());

    // q = new UnlimitedInt(den->get_array(), den->get_capacity(), den->get_sign(), den->get_size());
    // UnlimitedInt *t3 = gcd(p, q);

    // cout<<"t3"<<endl;
    // for(int i=0;i<t3->get_size();i++){
    //     cout<<t3->get_array()[i]<<endl;
    // }
    // cout<<"e3"<<endl;
    // UnlimitedInt*temp1 =UnlimitedInt :: div(p,t3);
    // UnlimitedInt*temp2 = UnlimitedInt :: div(q,t3);
    // UnlimitedInt* in1 = p;
    // UnlimitedInt* in2  = q;
    // p=temp1;
    // q = temp2;
    // delete in1;
    // delete in2;
    p = new UnlimitedInt(num->to_string());
    
    q = new UnlimitedInt(den->to_string());
    
    UnlimitedInt* t3 = gcd(den,num);
    
    p = UnlimitedInt :: div(num,t3);
    
    q = UnlimitedInt :: div(den,t3);
    
    //delete t3;


    
}

UnlimitedRational ::~UnlimitedRational()
{
    //cout<<"enrat"<<endl;
    if(p){
    delete p;
    }if(q){
    delete q;
    }
    //cout<<"enraten"<<endl;
}
UnlimitedInt *UnlimitedRational::get_p()
{
    return p;
}
UnlimitedInt *UnlimitedRational ::get_q()
{
    
    return q;
}
string UnlimitedRational ::get_p_str()
{
    return p->to_string();
}
string UnlimitedRational ::get_q_str()
{
    return q->to_string();
}
string UnlimitedRational ::get_frac_str()
{
    string res = p->to_string() + "/" + q->to_string();
    return res;
}
// UnlimitedInt *gcd(UnlimitedInt *i1, UnlimitedInt *i2)
// {
//     int *u2 = i2->get_array();
//     int s2 = i2->get_size();
//     bool check;
//     for (int i = 0; i < s2; i++)
//     {
//         if (u2[i] == 0)
//         {
//             check = true;
//         }
//         else
//         {
//             check = false;
//             break;
//         }
//     }
//     if (check)
//     {
//         return i1;
//     }
//     return gcd(i2, UnlimitedInt::mod(i1, i2));
// }
UnlimitedRational *UnlimitedRational::add(UnlimitedRational *i1, UnlimitedRational *i2)
{

    UnlimitedInt *p1 = i1->get_p();
    UnlimitedInt *q1 = i1->get_q();
    UnlimitedInt *p2 = i2->get_p();
    UnlimitedInt *q2 = i2->get_q();
    int *u1 = q1->get_array();
    int s1 = q1->get_size();
    bool check1;
    //cout<<"w2"<<endl;
    for (int i = 0; i < s1; i++)
    {
        if (u1[i] == 0)
        {
            check1 = true;
        }
        else
        {
            check1 = false;
            break;
        }
    }
    //cout<<"w3"<<endl;
    int *u2 = q2->get_array();
    int s2 = q2->get_size();
    bool check2;
    //cout<<"w4"<<endl;
    for (int i = 0; i < s2; i++)
    {
        if (u2[i] == 0)
        {
            check2 = true;
        }
        else
        {
            check2 = false;
            break;
        }
    }
    if (check1 || check2)
    {
        UnlimitedInt *z = new UnlimitedInt(0);
        return new UnlimitedRational(z, z);
    }

    UnlimitedInt *t1 = UnlimitedInt::mul(p1, q2);
    //cout<<"t1"<<endl;

    for(int i=0;i<t1->get_size();i++){
        //cout<<t1->get_array()[i]<<endl;
    }
    //cout<<"e1"<<endl;
   
    UnlimitedInt *t2 = UnlimitedInt::mul(p2, q1);
    for(int i=0;i<t1->get_size();i++){
        //cout<<t2->get_array()[i]<<endl;
    }
   //cout<<"e2"<<endl;
    UnlimitedInt*temp1 = UnlimitedInt :: add(t1, t2);
    //cout<<"er"<<endl;
    UnlimitedInt*temp2 = UnlimitedInt:: mul(q1,q2);
   //  UnlimitedInt *t3 = gcd(temp1, temp2);
   
     // temp1 = UnlimitedInt :: div(temp1,t3);

    // // cout<<"hj"<<endl;
    // // for(int i=0;i<t1->get_size();i++){
    // //     cout<<t1->get_array()[i]<<endl;
    // // }
    //  temp2 = UnlimitedInt :: div(temp2,t3);
    // delete t1;
    // delete t2;
    // delete temp1;
    // delete temp2;
    

    UnlimitedRational *res = new UnlimitedRational(temp1, temp2);
    //cout<<"exitrational"<<endl;
    return res;
    
}
UnlimitedRational *UnlimitedRational::sub(UnlimitedRational *i1, UnlimitedRational *i2)
{
    UnlimitedInt *p1 = i1->get_p();
    UnlimitedInt *q1 = i1->get_q();
    UnlimitedInt *p2 = i2->get_p();
    UnlimitedInt *q2 = i2->get_q();
    int *u1 = q1->get_array();
    int s1 = q1->get_size();
    bool check1;
    for (int i = 0; i < s1; i++)
    {
        if (u1[i] == 0)
        {
            check1 = true;
        }
        else
        {
            check1 = false;
            break;
        }
    }
    int *u2 = q2->get_array();
    int s2 = q2->get_size();
    bool check2;
    for (int i = 0; i < s2; i++)
    {
        if (u2[i] == 0)
        {
            check2 = true;
        }
        else
        {
            check2 = false;
            break;
        }
    }
    if (check1 || check2)
    {
        UnlimitedInt *z = new UnlimitedInt(0);
        return new UnlimitedRational(z, z);
    }
    UnlimitedInt *t1 = UnlimitedInt :: mul(p1, q2);
    UnlimitedInt *t2 = UnlimitedInt ::mul(p2, q1);
    UnlimitedInt* temp1 = UnlimitedInt :: sub(t1, t2);
    UnlimitedInt*temp2 = UnlimitedInt :: mul(q1,q2);
    // UnlimitedInt *t3 = gcd(t1, t2);
    
    // t1->div(t1, t3);
    // t2->div(t2, t3);
    UnlimitedRational *res = new UnlimitedRational(temp1, temp2);
    return res;
}
UnlimitedRational *UnlimitedRational ::mul(UnlimitedRational *i1, UnlimitedRational *i2)
{
    UnlimitedInt *p1 = i1->get_p();
    UnlimitedInt *q1 = i1->get_q();
    UnlimitedInt *p2 = i2->get_p();
    UnlimitedInt *q2 = i2->get_q();
    int *u1 = q1->get_array();
    int s1 = q1->get_size();
    bool check1;
    for (int i = 0; i < s1; i++)
    {
        if (u1[i] == 0)
        {
            check1 = true;
        }
        else
        {
            check1 = false;
            break;
        }
    }
    int *u2 = q2->get_array();
    int s2 = q2->get_size();
    bool check2;
    for (int i = 0; i < s2; i++)
    {
        if (u2[i] == 0)
        {
            check2 = true;
        }
        else
        {
            check2 = false;
            break;
        }
    }
    if (check1 || check2)
    {
        UnlimitedInt *z = new UnlimitedInt(0);
        return new UnlimitedRational(z, z);
    }
    UnlimitedInt *t1 = t1->mul(p1, p2);
    UnlimitedInt *t2 = t2->mul(q2, q1);
    // UnlimitedInt *t3 = gcd(t1, t2);
    // t1->div(t1, t3);
    // t2->div(t2, t3);
    UnlimitedRational *res = new UnlimitedRational(t1, t2);
    return res;
}
UnlimitedRational *UnlimitedRational::div(UnlimitedRational *i1, UnlimitedRational *i2)
{
    UnlimitedInt *p1 = i1->get_p();
    UnlimitedInt *q1 = i1->get_q();
    UnlimitedInt *p2 = i2->get_p();
    UnlimitedInt *q2 = i2->get_q();
    int *u1 = q1->get_array();
    int s1 = q1->get_size();
    bool check1;
    for (int i = 0; i < s1; i++)
    {
        if (u1[i] == 0)
        {
            check1 = true;
        }
        else
        {
            check1 = false;
            break;
        }
    }
    int *u2 = p2->get_array();
    int s2 = p2->get_size();
    bool check2;
    for (int i = 0; i < s2; i++)
    {
        if (u2[i] == 0)
        {
            check2 = true;
        }
        else
        {
            check2 = false;
            break;
        }
    }
    if (check1 || check2)
    {
        UnlimitedInt *z = new UnlimitedInt(0);
        return new UnlimitedRational(z, z);
    }
    UnlimitedInt *t1 = t1->mul(p1, q2);
    UnlimitedInt *t2 = t2->mul(p2, q1);
    // UnlimitedInt *t3 = gcd(t1, t2);
    // t1->div(t1, t3);
    // t2->div(t2, t3);
    UnlimitedRational *res = new UnlimitedRational(t1, t2);
    return res;
}
// int main()
// {
//     UnlimitedInt *p = new UnlimitedInt("5");
//     UnlimitedInt *q = new UnlimitedInt("11");
//     UnlimitedRational *a = new UnlimitedRational(p, q);
//     //cout<<a->get_frac_str()<<endl;
//     UnlimitedInt *r = new UnlimitedInt("8");
//     UnlimitedInt *s = new UnlimitedInt("-7");
//     UnlimitedRational *b = new UnlimitedRational(r, s);
//     //cout<<b->get_frac_str()<<endl;
//     UnlimitedRational *f = f->div(a, b);
//     cout << f->get_frac_str() << endl;
// }
